-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10 Jan 2021 pada 21.27
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siak`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kades`
--

CREATE TABLE `tbl_kades` (
  `id_kpldesa` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `jabatan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_kades`
--

INSERT INTO `tbl_kades` (`id_kpldesa`, `nama`, `status`, `jabatan`) VALUES
(1, 'Amas Subhan S, Hut', 'Aktif', 'Kepala Desa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_mutasi`
--

CREATE TABLE `tbl_mutasi` (
  `id_mutasi` int(11) NOT NULL,
  `nik_mutasi` varchar(20) NOT NULL,
  `nokk_mutasi` varchar(20) NOT NULL,
  `nama_mutasi` varchar(20) NOT NULL,
  `tglahir_mutasi` date NOT NULL,
  `tempat_mutasi` varchar(11) NOT NULL,
  `kelamin_mutasi` varchar(11) NOT NULL,
  `usia_mutasi` int(11) NOT NULL,
  `status_mutasi` varchar(20) NOT NULL,
  `alamat_mutasi` varchar(30) NOT NULL,
  `pekerjaan_mutasi` varchar(29) NOT NULL,
  `penghasilan_mutasi` varchar(30) NOT NULL,
  `pendidikan_mutasi` varchar(11) NOT NULL,
  `agama_mutasi` varchar(11) NOT NULL,
  `desa_mutasi` varchar(11) NOT NULL,
  `jpenduduk_mutasi` varchar(11) NOT NULL,
  `dnbantuan_mutasi` varchar(11) NOT NULL,
  `kecamatan_mutasi` varchar(11) NOT NULL,
  `kabupaten_mutasi` varchar(11) NOT NULL,
  `rt_mutasi` int(11) NOT NULL,
  `rw_mutasi` int(11) NOT NULL,
  `negara_mutasi` varchar(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_mutasi`
--

INSERT INTO `tbl_mutasi` (`id_mutasi`, `nik_mutasi`, `nokk_mutasi`, `nama_mutasi`, `tglahir_mutasi`, `tempat_mutasi`, `kelamin_mutasi`, `usia_mutasi`, `status_mutasi`, `alamat_mutasi`, `pekerjaan_mutasi`, `penghasilan_mutasi`, `pendidikan_mutasi`, `agama_mutasi`, `desa_mutasi`, `jpenduduk_mutasi`, `dnbantuan_mutasi`, `kecamatan_mutasi`, `kabupaten_mutasi`, `rt_mutasi`, `rw_mutasi`, `negara_mutasi`, `id_user`) VALUES
(9, '123452', '543121', 'Nezar Yuzdi Alamsyah', '2000-02-10', 'Tanggerang', 'Laki-Laki', 20, 'BELUM MENIKAH', 'Pedes', 'TIDAK BEKERJA', '0', 'SMA', 'ISLAM', 'DUSUN PEDES', 'TETAP', 'BANKAB', 'Pedes', 'Karawang', 1, 2, 'Indonesia', 0),
(10, '123452', '543121', 'Nezar Yuzdi Alamsyah', '2000-02-10', 'Tanggerang', 'Pilih', 20, 'Pilih', 'Pedes', 'TIDAK BEKERJA', '0', 'SMA', 'ISLAM', 'DUSUN PEDES', 'Pilih', 'Pilih', 'Pedes', 'Karawang', 1, 2, 'Indonesia', 0),
(11, '321502401920001', '12345', 'NAUFAL ISKANDAR', '1992-01-24', 'Karawang', 'Pilih', 29, 'Pilih', 'PEDES', 'WIRASWASTA', '3.000.000', 'S1', 'ISLAM', 'DUSUN PEDES', 'Pilih', 'Pilih', 'PEDES', 'KARAWANG', 5, 1, 'Indonesia', 0),
(12, '123452', '543121', 'Nezar Yuzdi Alamsyah', '2000-02-10', 'Tanggerang', 'Pilih', 20, 'Pilih', 'Pedes', 'TIDAK BEKERJA', '0', 'SMA', 'ISLAM', 'DUSUN PEDES', 'PINDAH', 'Pilih', 'Pedes', 'Karawang', 1, 2, 'Indonesia', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_penduduk`
--

CREATE TABLE `tbl_penduduk` (
  `id` int(11) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nokk` varchar(20) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `tglahir` date NOT NULL,
  `tempat` varchar(11) NOT NULL,
  `kelamin` varchar(11) NOT NULL,
  `usia` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `pekerjaan` varchar(30) NOT NULL,
  `penghasilan` varchar(30) NOT NULL,
  `pendidikan` varchar(11) NOT NULL,
  `agama` varchar(11) NOT NULL,
  `desa` varchar(11) NOT NULL,
  `jpenduduk` varchar(11) NOT NULL,
  `dnbantuan` varchar(11) NOT NULL,
  `kecamatan` varchar(11) NOT NULL,
  `kabupaten` varchar(11) NOT NULL,
  `rt` int(11) NOT NULL,
  `rw` int(11) NOT NULL,
  `negara` varchar(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_penduduk`
--

INSERT INTO `tbl_penduduk` (`id`, `nik`, `nokk`, `nama`, `tglahir`, `tempat`, `kelamin`, `usia`, `status`, `alamat`, `pekerjaan`, `penghasilan`, `pendidikan`, `agama`, `desa`, `jpenduduk`, `dnbantuan`, `kecamatan`, `kabupaten`, `rt`, `rw`, `negara`, `id_user`) VALUES
(5, '123452', '543121', 'Nezar Yuzdi Alamsyah', '2000-02-10', 'Tanggerang', 'Laki-Laki', 20, 'BELUM MENIKAH', 'Pedes', 'TIDAK BEKERJA', '0', 'SMA', 'ISLAM', 'DUSUN PEDES', 'TETAP', 'BANPROV', 'Pedes', 'Karawang', 1, 2, 'Indonesia', 0),
(6, '123451', '543213', 'Mochamad Kiki Subagj', '1998-02-25', 'karawang', 'Laki-Laki', 22, 'BELUM MENIKAH', 'jl.kertabumi no.99', 'TIDAK BEKERJA', '0', 'SMA', 'ISLAM', 'BAYUR 1', 'PINDAH', 'VST', 'Pedes', 'Karawang', 2, 4, 'Indonesia', 0),
(8, '321502401920001', '12345', 'NAUFAL ISKANDAR', '1992-01-24', 'Karawang', 'Laki-Laki', 29, 'MENIKAH', 'PEDES', 'WIRASWASTA', '3.000.000', 'S1', 'ISLAM', 'DUSUN PEDES', 'TETAP', 'BANPROV', 'PEDES', 'KARAWANG', 5, 1, 'Indonesia', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(22) NOT NULL,
  `username` varchar(22) NOT NULL,
  `password` varchar(22) NOT NULL,
  `status` varchar(22) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `password`, `status`) VALUES
(1, 'Admin', 'admin', 'admin', 'Admin'),
(12, 'Amas Subhan S, Hut', 'kpl_desa', '123', 'User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kades`
--
ALTER TABLE `tbl_kades`
  ADD PRIMARY KEY (`id_kpldesa`);

--
-- Indexes for table `tbl_mutasi`
--
ALTER TABLE `tbl_mutasi`
  ADD PRIMARY KEY (`id_mutasi`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tbl_penduduk`
--
ALTER TABLE `tbl_penduduk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_kades`
--
ALTER TABLE `tbl_kades`
  MODIFY `id_kpldesa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mutasi`
--
ALTER TABLE `tbl_mutasi`
  MODIFY `id_mutasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_penduduk`
--
ALTER TABLE `tbl_penduduk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
