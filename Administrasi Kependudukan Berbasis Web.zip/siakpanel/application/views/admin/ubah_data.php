<div id="layoutSidenav_content">
<main>
   <div class="container">
   <div class="row mt-3">
   </div>

   <div class="card mb-4">
        <div class="card-body">
            <label>
            <h5>Form Ubah Data</h5>
            </label>
        </div>
        </div>
    <?php foreach($ubah_data as $u){ ?>
    <form action="<?php echo base_url(). 'admin/update'; ?>" method="post">
    <table class="table table-striped table-condensed table-hover" id="datatable">
    <tr>
    <th>Nama Lengkap</th>
    <td width="1%">:</td>
    <td>
    <input type="hidden" name="id" value="<?php echo $u->id ?>">
    <input type="text" class="form-control" name="nama" value="<?php echo $u->nama ?>"  style="width:500px">
    </td>
    </tr>

    <tr>
    <th>Tempat Lahir</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="tempat" value="<?php echo $u->tempat ?>"  style="width:500px"></td>
    </tr>
    
    <tr>
    <th>Tanggal Lahir</th>
    <td width="1%">:</td>
    <td><input type="date" class="form-control" name="tglahir" value="<?php echo $u->tglahir ?>"  style="width:500px"></td>
    </tr>

    <tr>
    <th>Kelamin</th>
    <td width="1%">:</td>
    <td>
    <select id="kelamin" name="kelamin">
    <option value="<?php echo $u->kelamin ?>" selected><?php echo $u->kelamin ?></option>
    <option value="L">Laki-Laki</option>
    <option value="P">Perempuan</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Usia</th>
    <td width="1%">:</td>
    <td><input type="number" class="form-control" name="usia" value="<?php echo $u->usia ?>" style="width:500px"></td>
    </tr>

    <tr>
    <th>Status</th>
    <td width="1%">:</td>
    <td>
    <select id="status" name="status">
    <option value="<?php echo $u->status ?>" selected><?php echo $u->status ?></option>
    <option>MENIKAH</option>
    <option>BELUM MENIKAH</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Alamat</th>
    <td width="1%">:</td>
    <td><input type="textarea" class="form-control" name="alamat" value="<?php echo $u->alamat ?>" style="width:500px"></td>
    </tr>
    
    <tr>
    <th>Pekerjaan</th>
    <td width="1%">:</td>
    <td>
    <select id="pekerjaan" name="pekerjaan">
    <option value="<?php echo $u->pekerjaan ?>" selected><?php echo $u->pekerjaan ?></option>
    <option>SWASTA</option>
    <option>WIRASWASTA</option>
    <option>BUMN</option>
    <option>PETANI</option>
    <option>NELAYAN</option>
    <option>TIDAK BEKERJA</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Penghasilan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="penghasilan" value="<?php echo $u->penghasilan ?>" style="width:500px"></td>
    </tr>

    <tr>
    <th>Pendidikan Terakhir</th>
    <td width="1%">:</td>
    <td>
    <select id="pendidikan" name="pendidikan">
    <option value="<?php echo $u->pendidikan ?>" selected><?php echo $u->pendidikan ?></option>
    <option>SD</option>
    <option>SMP</option>
    <option>SMA</option>
    <option>SMK</option>
    <option>D3</option>
    <option>S1</option>
    <option>S2</option>
    <option>S3</option>
    <option>TIDAK SEKOLAH</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Agama</th>
    <td width="1%">:</td>
    <td>
    <select id="agama" name="agama">
    <option value="<?php echo $u->agama ?>" selected><?php echo $u->agama ?></option>
    <option>ISLAM</option>
    <option>KRISTEN</option>
    <option>BUDHA</option>
    <option>HINDU</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Dusun</th>
    <td width="1%">:</td>
    <td>
    <select id="desa" name="desa">
    <option value="<?php echo $u->desa ?>" selected><?php echo $u->desa ?></option>
    <option>DUSUN PEDES 1</option>
    <option>DUSUN PEDES 2</option>
    <option>BAYUR 1</option>
    <option>BAYUR 2</option>
    <option>JATI MUKA</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <th>Jenis Penduduk</th>
    <td width="1%">:</td>
    <td>
    <select id="jpenduduk" name="jpenduduk">
    <option value="<?php echo $u->jpenduduk ?>" selected><?php echo $u->jpenduduk ?></option>
    <option>TETAP</option>
    <option>PINDAH</option>
    <option>PENDATANG</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <th>Jenis Bantuan</th>
    <td width="1%">:</td>
    <td>
    <select id="dnbantuan" name="dnbantuan">
    <option value="<?php echo $u->dnbantuan ?>" selected><?php echo $u->dnbantuan ?></option>
    <option>BLT</option>
    <option>VST</option>
    <option>BANPROV</option>
    <option>BANKAB</option>
    <option>BANPERTANIAN</option>
    <option>BANPERLUASAN</option>
    <option>DTKS</option>
    <option>NON DTKS</option>
    <option>TIDAK ADA</option>
    </select>
    </td>
    </tr>  

    <tr>
    <th>Kecamatan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="kecamatan" value="<?php echo $u->kecamatan ?>" style="width:500px"></td>
    </tr>

    <tr>
    <th>Kabupaten</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="kabupaten" value="<?php echo $u->kabupaten ?>" style="width:500px"></td>
    </tr>

    <tr>
    <th>Rt</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="rt" value="<?php echo $u->rt ?>" style="width:500px"></td>
    </tr>

    <tr>
    <th>Rw</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="rw" value="<?php echo $u->rw ?>" style="width:500px"></td>
    </tr>

    <tr>
    <th>Kewarganegaraan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="negara" value="<?php echo $u->negara ?>" style="width:500px"></td>
    </tr>

    <td>
    <button type="submit" class="btn btn-primary btn-lg">
    <i class="fa fa-save"></i> Simpan
    </button>
    </td>
    </table>
    </form>
    <?php } ?>
    </div>
    </main>