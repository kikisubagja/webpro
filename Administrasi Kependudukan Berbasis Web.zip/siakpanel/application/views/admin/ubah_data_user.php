<div id="layoutSidenav_content">
<main>
   <div class="container">
   <div class="row mt-3">
   </div>

   <div class="card mb-4">
        <div class="card-body">
            <label>
            <h5>Form Ubah Data</h5>
            </label>
        </div>
        </div>
    <?php foreach($ubah_data as $u){ ?>
    <form action="<?php echo base_url(). 'admin/updateuser'; ?>" method="post">
    <table class="table table-striped table-condensed table-hover" id="datatable">
    <tr>
    <th>Nama Lengkap</th>
    <td width="1%">:</td>
    <td>
    <input type="hidden" name="id_user" value="<?php echo $u->id_user ?>">
    <input type="text" class="form-control" name="nama" value="<?php echo $u->nama ?>"  style="width:500px">
    </td>
    </tr>

    <tr>
    <th>Username</th>
    <td width="1%">:</td>
    <td>
    <input type="text" class="form-control" name="username" value="<?php echo $u->username ?>"  style="width:500px">
    </td>
    </tr>

    <tr>
    <th>password</th>
    <td width="1%">:</td>
    <td>
    <input type="password" class="form-control" name="password" value="<?php echo $u->password ?>"  style="width:500px">
    </td>
    </tr>


    <tr>
    <th>Status/Role</th>
    <td width="1%">:</td>
    <td>
    <select id="status" name="status">
    <option value="<?php echo $u->status ?>" selected><?php echo $u->status ?></option>
    <option>Admin</option>
    <option>User</option>
    </select>
    </td>
    </tr>
    <td>
    <button type="submit" class="btn btn-primary btn-lg">
    <i class="fa fa-save"></i> Simpan
    </button>
    </td>
    </table>
    </form>
    <?php } ?>
    </div>
    </main>