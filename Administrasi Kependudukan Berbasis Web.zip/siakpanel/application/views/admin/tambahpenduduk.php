<div id="layoutSidenav_content">
<main>
   <div class="container">
   <div class="row mt-3">
   </div>

   <div class="card mb-4">
        <div class="card-body">
            <label>
            <h5>Form Tambah Data</h5>
            </label>
        </div>
        </div>
  
    <form action="tambahpenduduk" method="post">
    <table class="table table-striped table-condensed table-hover" id="datatable">
    <tr>
    <th>NIK</th>
    <td width="1%">:</td>
    <td><input type="number" class="form-control" name="nik"  style="width:500px" required></td>
    </tr>

    <tr>
    <th>No.KK</th>
    <td width="1%">:</td>
    <td><input type="number" class="form-control" name="nokk"  style="width:500px" required></td>
    </tr>

    <tr>
    <th>Nama Lengkap</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="nama"  style="width:500px"></td>
    </tr>

    <tr>
    <th>Tempat Lahir</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="tempat"  style="width:500px"></td>
    </tr>
    
    <tr>
    <th>Tanggal Lahir</th>
    <td width="1%">:</td>
    <td><input type="date" class="form-control" name="tglahir"  style="width:500px"></td>
    </tr>

    <tr>
    <th>Kelamin</th>
    <td width="1%">:</td>
    <td>
    <select id="kelamin" name="kelamin">
    <option>Laki-Laki</option>
    <option>Perempuan</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Usia</th>
    <td width="1%">:</td>
    <td><input type="number" class="form-control" name="usia" value="0" style="width:500px"></td>
    </tr>

    <tr>
    <th>Status</th>
    <td width="1%">:</td>
    <td>
    <select id="status" name="status">
    <option>MENIKAH</option>
    <option>BELUM MENIKAH</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Alamat</th>
    <td width="1%">:</td>
    <td><input type="textarea" class="form-control" name="alamat" style="width:500px"></td>
    </tr>
    
    <tr>
    <th>Pekerjaan</th>
    <td width="1%">:</td>
    <td>
    <select id="pekerjaan" name="pekerjaan">
    <option>SWASTA</option>
    <option>WIRASWASTA</option>
    <option>BUMN</option>
    <option>PETANI</option>
    <option>NELAYAN</option>
    <option>TIDAK BEKERJA</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Penghasilan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="penghasilan" value="0" style="width:500px"></td>
    </tr>

    <tr>
    <th>Pendidikan Terakhir</th>
    <td width="1%">:</td>
    <td>
    <select id="pendidikan" name="pendidikan">
    <option>SD</option>
    <option>SMP</option>
    <option>SMA</option>
    <option>SMK</option>
    <option>D3</option>
    <option>S1</option>
    <option>S2</option>
    <option>S3</option>
    <option>TIDAK SEKOLAH</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Agama</th>
    <td width="1%">:</td>
    <td>
    <select id="agama" name="agama">
    <option>ISLAM</option>
    <option>KRISTEN</option>
    <option>BUDHA</option>
    <option>HINDU</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Dusun</th>
    <td width="1%">:</td>
    <td>
    <select id="desa" name="desa">
    <option>DUSUN PEDES 1</option>
    <option>DUSUN PEDES 2</option>
    <option>BAYUR 1</option>
    <option>BAYUR 2</option>
    <option>JATI MUKA</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <th>Jenis Penduduk</th>
    <td width="1%">:</td>
    <td>
    <select id="jpenduduk" name="jpenduduk">
    <option>TETAP</option>
    <option>PINDAH</option>
    <option>PENDATANG</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <th>Jenis Bantuan</th>
    <td width="1%">:</td>
    <td>
    <select id="dnbantuan" name="dnbantuan">
    <option>BLT</option>
    <option>VST</option>
    <option>BANPROV</option>
    <option>BANKAB</option>
    <option>BANPERTANIAN</option>
    <option>BANPERLUASAN</option>
    <option>DTKS</option>
    <option>NON DTKS</option>
    <option>TIDAK ADA</option>
    </select>
    </td>
    </tr>  

    <tr>
    <th>Kecamatan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="kecamatan" style="width:500px"></td>
    </tr>

    <tr>
    <th>Kabupaten</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="kabupaten" style="width:500px"></td>
    </tr>

    <tr>
    <th>Rt</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="rt" style="width:500px"></td>
    </tr>

    <tr>
    <th>Rw</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="rw" style="width:500px"></td>
    </tr>

    <tr>
    <th>Kewarganegaraan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="negara" style="width:500px"></td>
    </tr>

    <td>
    <button type="submit" name="save" class="btn btn-primary btn-lg">
    <i class="fa fa-save"></i> Simpan
    </td>
    </button>
    </table>
    </form>
    </div>
    </main>