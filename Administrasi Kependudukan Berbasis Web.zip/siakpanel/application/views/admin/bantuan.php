<div id="layoutSidenav_content">
<main>
   <div class="container">
   <div class="row mt-3">
   </div>
   <center><h3>E-BOOK Buku Panduan - SIAK WEB PANEL</h3>
   <embed type="application/pdf" src="<?= base_url('assets/ebook/BUKU PANDUAN.pdf');?>" width="600" height="400"></embed>
  </center>
  <br>
  <br>
  <br>











