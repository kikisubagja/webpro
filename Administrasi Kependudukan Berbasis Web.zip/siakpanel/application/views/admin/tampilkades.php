<div id="layoutSidenav_content">
    <main>
    <div class="container">
    <div class="row mt-3">
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <a href="<?php base_url('admin/tampilkades')?>">
            <div class="btn btn-danger"><i class="fas fa-eye"></i> Lihat Data</div>
            </a>

            <label>
            <a href="tambahkades">
           <button type="button" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Data</button>
            </a>
            </label>
        </div>
        </div>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No.</th>
      <th scope="col">Nama</th>
      <th scope="col">Status</th>
      <th scope="col">Jabatan</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <?php 
    $no = 1;
    foreach($kades as $u){ 
    ?>
  <tbody>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $u->nama ?></td>
      <td><?php echo $u->status ?></td>
      <td><?php echo $u->jabatan ?></td>
      <td onclick="javascript: return confirm('Anda yakin akan menghapus?')"><?php echo anchor('admin/hapuskades/'.$u->id_kpldesa, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></td>
    </tr>
  </tbody>
  <?php } ?>
</table>
<div class="card body">
<h5>Keterangan :</h5>
<a>Untuk menghapus -><span class="badge badge-danger"><i class="fas fa-trash"></i></span></a>
</div>
    </div>
    </main>
   