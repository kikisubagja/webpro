
        <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h3 class="mt-4">Selamat Datang </h3>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Info Jumlah Penduduk</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-info text-white mb-4">
                                    <div class="card-body"><?php echo $total; ?> Orang</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                    Total Penduduk
                                        <a class="small text-white stretched-link" href="<?= base_url('admin/tampilpenduduk')?>"></a>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-info text-white mb-4">
                                    <div class="card-body"><?php echo $totaldatang; ?> Orang</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                       Penduduk Pendatang
                                        <a class="small text-white stretched-link" href="#"></a>
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-info text-white mb-4">
                                    <div class="card-body"><?php echo $totaltetap; ?> Orang</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                    Penduduk Tetap
                                        <a class="small text-white stretched-link" href="#"></a>
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-info text-white mb-4">
                                    <div class="card-body"><?php echo $totalpindah; ?> Orang</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                    Penduduk Pindah
                                        <a class="small text-white stretched-link" href="#"></a>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-info text-white mb-4">
                                    <div class="card-body"><?php echo $totalmutasi; ?> Orang</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                    Penduduk Mutasi
                                        <a class="small text-white stretched-link" href="<?= base_url('admin/mutasidatatampil')?>"></a>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
