<div id="layoutSidenav_content">
    <main>
    <div class="container">
    <div class="row mt-3">
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <label>
            <a href="<?php base_url('admin/penduduk')?>">
           <button type="button" class="btn btn-danger"><i class="fas fa-eye"></i> Lihat Data</button>
            </a>
            </label>

            <label>
            <a href="tambahpenduduk">
           <button type="button" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Data</button>
            </a>
            </label>
        </div>
        </div>
        
       <label>
       <div class="navbar-form navbar-right">
        <?php echo form_open('admin/search') ?>
        <input type="text" name="keyword" placeholder="Masukan Nama/Nik">
        <button type="submit" class="btn btn-primary">Cari</button>
        <?php echo form_close()?>
        </div>
       </label>
       
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No.</th>
      <th scope="col">Nik</th>
      <th scope="col">Nama</th>
      <th scope="col">Kelamin</th>
      <th scope="col">Usia</th>
      <th scope="col">Pendidikan</th>
      <th scope="col">Pekerjaan</th>
      <th scope="col">Alamat</th>
      <th scope="col">Status</th>
      <th scope="col"></th>
      <th scope="col">Aksi</th>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <?php 
    $no = 1;
    foreach($penduduk as $u){ 
    ?>
  <tbody>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $u->nik ?></td>
      <td><?php echo $u->nama ?></td>
      <td><?php echo $u->kelamin ?></td>
      <td><?php echo $u->usia ?></td>
      <td><?php echo $u->pendidikan ?></td>
      <td><?php echo $u->pekerjaan ?></td>
      <td><?php echo $u->alamat ?></td>
      <td><?php echo $u->jpenduduk ?></td>
      <td onclick="javascript: return confirm('Anda yakin akan menghapus?')"><?php echo anchor('admin/hapus/'.$u->id, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></td>
      <td><?php echo anchor('admin/edit/' . $u->id, '<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>') ?></td>
      <td><?php echo anchor('admin/mutasidata/' . $u->id, '<div class="btn btn-warning btn-sm"><i class="fa fa-share-square"></i></div>') ?></td>
      <td><?php echo anchor('admin/cetak/' . $u->id, '<div class="btn btn-success btn-sm"><i class="fa fa-print"></i></div>') ?></td>

  </tbody>
  <?php } ?>
</table>
<div class="card body">
<h5>Keterangan :</h5>
<a>Untuk menghapus -><span class="badge badge-danger"><i class="fas fa-trash"></i></span></a>
<a>Untuk ubah data -><span class="badge badge-primary"><i class="fas fa-edit"></i></span></a>
<a>Untuk mutasi data -><span class="badge badge-warning"><i class="fas fa-share-square"></i></span></a>
<a>Untuk mencetak -><span class="badge badge-success"><i class="fas fa-print"></i></span></a>
</div>
    </div>
    </main>
   