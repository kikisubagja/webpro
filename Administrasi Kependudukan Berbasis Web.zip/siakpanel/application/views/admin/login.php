<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrasi Kependudukan</title>
    <link href="<?= base_url('assets/css/index.css')?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/style.css')?>" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <style type="text/css">
    body{
        background-image: url(<?php echo base_url("assets/img/desaground.png");?>);
        no-repeat fixed;
        -webkit-background-size: 100% 100%;
        -moz-background-size: 100% 100%;
        -o-background-size: 100% 100%;
        background-size: 100% 100%;
      
    }
</style>
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <?= $this->session->flashdata('pesan'); ?>
    <div class="fadeIn first">
     
      <img src="<?= base_url('assets/img/krw.png')?>" width="150" height="200" class="d-inline-block align-top" alt="">
    </div>

    <!-- Login Form -->
    <form action="" method="post">
      <?= form_error('username', ' <small class="text-danger">', '</small>'); ?>
      <br>
      <?= form_error('password', ' <small class="text-danger">', '</small>'); ?>
      <input type="text" name='username' id="username" class="fadeIn second" name="username" placeholder="Masukan Username" value='<?= set_value('username') ?>'>
      <input type="password" name='password' id="password" class="fadeIn third" name="password" placeholder="Masukan Password">
      <input type="submit" class="btn btn-primary" value="Masuk">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
    <a class="text-xs font-weight text-white text-uppercase mb-1">
         Desa Payungsari </br>
    </div>
</div>
</body>
</html>