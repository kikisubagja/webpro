<div id="layoutSidenav_content">
<main>
    <div class="container">

    <div class="row mt-3">
    </div>

    <ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Mutasi Data Penduduk</li>
    </ol>

    <?php foreach ($mutasidata as $u){ ?>
    <form action="<?php echo base_url().'admin/mutasidatasimpan';?>" method="post">
    <table class="table table-striped table-condensed table-hover" id="datatable">
    <tr>
    <th>NIK</th>
    <td width="1%">:</td>
    <td>
    <input type="hidden" name="id" value="<?php echo $u->id ?>">
    <input type="text" class="form-control" name="nik_mutasi" value="<?php echo $u->nik?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>No.KK</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="nokk_mutasi" value="<?php echo $u->nokk?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Nama Mutasi</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="nama_mutasi" value="<?php echo $u->nama?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Tempat Lahir</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="tempat_mutasi" value="<?php echo $u->tempat?>" style="width:500px" required></td>
    </tr>
    
    <tr>
    <th>Tanggal Lahir</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="tglahir_mutasi" value="<?php echo $u->tglahir?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Kelamin</th>
    <td width="1%">:</td>
    <td>
    <select id="kelamin" name="kelamin_mutasi" value="<?php echo $u->kelamin?>">
    <option>Pilih</option>
    <option>Laki-Laki</option>
    <option>Perempuan</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Usia</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="usia_mutasi" value="<?php echo $u->usia?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Status</th>
    <td width="1%">:</td>
    <td>
    <select id="jpenduduk" name="status_mutasi" value="<?php echo $u->status?>">
    <option>Pilih</option>
    <option>MENIKAH</option>
    <option>BELUM MENIKAH</option>
    </select>
    </td>
    </tr>

    <tr>
    <th>Alamat</th>
    <td width="1%">:</td>
    <td><input type="textarea" class="form-control" name="alamat_mutasi" value="<?php echo $u->alamat?>" style="width:500px" required></td>
    </tr>
    
    <tr>
    <th>Pekerjaan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="pekerjaan_mutasi" value="<?php echo $u->pekerjaan?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Penghasilan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="penghasilan_mutasi" value="<?php echo $u->penghasilan?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Pendidikan Terakhir</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="pendidikan_mutasi" value="<?php echo $u->pendidikan?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Agama</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="agama_mutasi" value="<?php echo $u->agama?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Dusun</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="desa_mutasi" value="<?php echo $u->desa?>" style="width:500px" required></td>
    </tr>
    
    <tr>
    <th>Jenis Penduduk</th>
    <td width="1%">:</td>
    <td>
    <select id="jpenduduk" name="jpenduduk_mutasi" value="<?php echo $u->jpenduduk?>">
    <option>Pilih</option>
    <option>TETAP</option>
    <option>PINDAH</option>
    <option>PENDATANG</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <th>Jenis Bantuan</th>
    <td width="1%">:</td>
    <td>
    <select id="jpenduduk" name="dnbantuan_mutasi" value="<?php echo $u->dnbantuan?>">
    <option>Pilih</option>
    <option>BLT</option>
    <option>VST</option>
    <option>BANPROV</option>
    <option>BANKAB</option>
    <option>BANPERTANIAN</option>
    <option>BANPERLUASAN</option>
    <option>DTKS</option>
    <option>NON DTKS</option>
    <option>TIDAK ADA</option>
    </select>
    </td>
    </tr>  

    <tr>
    <th>Kecamatan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="kecamatan_mutasi" value="<?php echo $u->kecamatan?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Kabupaten</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="kabupaten_mutasi" value="<?php echo $u->kabupaten?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Rt</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="rt_mutasi" value="<?php echo $u->rt?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Rw</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="rw_mutasi" value="<?php echo $u->rw?>" style="width:500px" required></td>
    </tr>

    <tr>
    <th>Kewarganegaraan</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="negara_mutasi" value="<?php echo $u->negara?>" style="width:500px" required></td>
    </tr>

    <tr>
    <td>
    <button type="submit" name="save" class="btn btn-primary btn-lg">
    <i class="fa fa-save"></i> Mutasi</button>
    </td>
    </tr>
    </table>
    </form>
    <?php  } ?>
    </div>
    </main>