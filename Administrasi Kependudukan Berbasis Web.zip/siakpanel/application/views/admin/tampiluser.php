<div id="layoutSidenav_content">
    <main>
    <div class="container">
    <div class="row mt-3">
    </div>
    <div class="card mb-4">
        <div class="card-body">
        <label>
            <a href="<?php base_url('admin/tampildatamutasi')?>">
           <button type="button" class="btn btn-danger"><i class="fas fa-eye"></i> Lihat Data</button>
            </a>
            </label>

            <label>
            <a href="tambahuser">
           <button type="button" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Data</button>
            </a>
            </label>
        </div>
        </div>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No.</th>
      <th scope="col">Nama</th>
      <th scope="col">Username</th>
      <th scope="col">Status</th>
      <th scope="col">Aksi</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <?php 
    $no = 1;
    foreach($user as $u){ 
    ?>
  <tbody>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $u->nama ?></td>
      <td><?php echo $u->username ?></td>
      <td><?php echo $u->status ?></td>
      <td onclick="javascript: return confirm('Anda yakin akan menghapus?')"><?php echo anchor('admin/hapususer/'.$u->id_user, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></td>
      <td><?php echo anchor('admin/edituser/' . $u->id_user, '<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>') ?></td>
    </tr>
  </tbody>
  <?php } ?>
</table>
<div class="card body">
<h5>Keterangan :</h5>
<a>Untuk menghapus -><span class="badge badge-danger"><i class="fas fa-trash"></i></span></a>
<a>Untuk mengubah -><span class="badge badge-primary"><i class="fas fa-edit"></i></span></a>
</div>
    </div>
    </main>
   