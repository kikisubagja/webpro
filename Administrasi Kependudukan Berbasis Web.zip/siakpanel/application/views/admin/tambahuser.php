<div id="layoutSidenav_content">
<main>
   <div class="container">
   <div class="row mt-3">
   </div>
   <div class="card mb-4">
        <div class="card-body">
            <label>
            <h5>Form Tambah Data</h5>
            </label>
        </div>
        </div>
    <form action="tambahuser" method="post">
    <table class="table table-striped table-condensed table-hover" id="datatable">
    <tr>
    <th>Nama</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="nama"  style="width:500px" required></td>
    </tr>

    <tr>
    <th>Username</th>
    <td width="1%">:</td>
    <td><input type="text" class="form-control" name="username"  style="width:500px" required></td>
    </tr>

    <tr>
    <th>Password</th>
    <td width="1%">:</td>
    <td><input type="password" class="form-control" name="password"  style="width:500px"></td>
    </tr>

    <tr>
    <th>Status/Role</th>
    <td width="1%">:</td>
    <td>
    <select id="status" name="status">
    <option>Admin</option>
    <option>User</option>
    </select>
    </td>
    </tr>
    
    <td>
    <button type="submit" name="save" class="btn btn-primary btn-lg">
    <i class="fa fa-save"></i> Simpan
    </td>
    </button>
    </table>
    </form>
    </div>
    </main>