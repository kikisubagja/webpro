<style type="text/css">
    @media print and (width: 8.5in) and (height: 11in) {
        @page {
            margin: 0cm;
        }
    }

    .justify {
        text-align: justify;
    }

    .table {
        border: 100px solid black;
        border-collapse: collapse;
        padding: 2px;
    }

    .lead {
        font-weight: bold;
        text-decoration: underline;
        margin-bottom: -20px;
    }

    #lead {
        width: auto;
        position: relative;
        margin: 15px 0 0 55%;
    }
</style>
<style type="text/css" media="print">
    @page {
        size: portrait;
    }
</style>

<img src="../../assets/img/krw.png" style="position: absolute; width: 60px; height: auto;">

<?php foreach ($tbl_penduduk as $tbl_penduduk) : ?>

    <center>
        <font size="5px"><b>PEMERINTAH KABUPATEN KARAWANG</b></font><br />
        <font size="5px"><b>KECAMATAN PEDES</b></font><br />
        <font size="5px"><b>DESA PAYUNGSARI</b></font><br />
        <font size="4px"><b>Alamat : Kecamatan Pedes, Kabupaten Karawang, Jawa Barat, Indonesia. </b></font><br />
        <font size="4px"><b>Telp (0267-404xxxx)</b></font><br />
    </center>
    <hr size="1px">
    <center>
        <font size="5px"><b>SURAT KETERANGAN DOMISILI</b></font>
        <hr width="400px">
    </center>
    <center>
        <font size="5px"><b>Nomor :</b></font>
    </center>
    <br>
    <table>
        <tr>
            <td valign="top" width="50%">Yang bertanda tangan di bawah ini &nbsp:</td>
        </tr>
        <tr>
        
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp  Nama &nbsp &nbsp &nbsp:</td>
        
            <td>
                <p style="text-align:justify;">
                   
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Jabatan &nbsp &nbsp:</td>
            <td>
                <p style="text-align:justify;">
                    
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Alamat  &nbsp &nbsp:</td>
       
            <td>
                <p style="text-align:justify;">
                    
                </p>
            </td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <td valign="top" width="50%">Menerangkan bahwa </td> 
            <td>:</td>
        </tr>
    
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Nama</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['nama']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Temppat, Tanggal Lahir</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['tempat']; ?>, <?php echo  $tbl_penduduk['tglahir']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Jenis Kelamin</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['kelamin']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Pekerjaan</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['pekerjaan']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Agama</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['agama']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Status Perkawinan</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['status']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Kewarganegaraan</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['negara']; ?>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top" width="20%" style="text-align:justify;">&nbsp &nbsp Alamat</td>
            <td>:</td>
            <td>
                <p style="text-align:justify;">
                    <?php echo $tbl_penduduk['alamat']; ?>
                </p>
            </td>
        </tr>
    </table>
    
    <table>
        <p style="text-align:justify;"> <b>Demikian surat keterangan domisili ini kami buat sebagaimana perlunya semoga dapat
                digunakan sebagaimana mestinya. Dan berkepentingan agar menjadi maklum.
            </b> </p>
    </table>


    <br>
    <table>
        <tr>
            <td>Karawang, .....</td>
            <td></td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <td>Kepala Desa/ Desa Payungsari</td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <br>
            <br>
            <br>
            <td>Amas Subhan S, Hut</td>
        </tr>
    </table>

<?php endforeach; ?>
<script>
    window.print();
</script>