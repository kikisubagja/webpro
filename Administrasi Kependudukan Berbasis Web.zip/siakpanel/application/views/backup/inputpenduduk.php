<div id="layoutSidenav_content">
    <main>
    <div class="container">
        <?php if ($this->session->flashdata('flash') ) : ?>
        <div class="row mt-3">
            <div class="col-md-6">
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
               Data Berhasil<strong>Ditambahkan</strong>
               <?= $this->session->flashdata('flash'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            </div>
        </div>
        <?php endif; ?>

    <div class="row mt-3">
        <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                Form Tambah Data Penduduk
            </div>
            <div class="card-body">
            <?php if( validation_errors() ) : ?>
            <div class="alert alert-danger" role="alert">
            <?= validation_errors();?>
                </div>
            <?php endif; ?>
            <form action="" method="post">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="nik">NIK</span>
                        </div>
                             <input type="number" name="nik" class="form-control">
                                </div>

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="nokk">No. KK</span>
                            </div>
                                <input type="number" name="nokk" class="form-control">
                                </div>

              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="nama">Nama</span>
                             </div>
                                <input type="text" name="nama" class="form-control">
                                    </div>

              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="tempat">Tempat Lahir</span>
                             </div>
                                 <input type="text" name="tempat" class="form-control">
                                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="kecamatan">Kecamatan</span>
                              </div>
                                  <input type="text" name="kecamatan" class="form-control">
                                     </div>

                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="kabupaten">Kabupaten</span>
                                    </div>
                                     <input type="text" name="kabupaten" class="form-control">
                                         </div>

              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="tglahir">Tanggal Lahir</span>
                            </div>
                                 <input type="date" name="tglahir" class="form-control">
                                     </div>

             <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="kelamin">Jenis Kelamin</label>
                     </div>
                         <select class="custom-select" id="kelamin" name="kelamin">
                            <option selected>Pilih</option>
                            <option>Laki-Laki</option>
                            <option>Perempuan</option>
                            </select>
                            </div>
                            
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="usia">Usia</span>
                           </div>
                            <input type="number" name="usia" class="form-control">
                              </div>

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="status">Status Perkawinan</label>
                            </div>
                            <select class="custom-select" id="status" name="status">
                                <option selected>Pilih</option>
                                <option>Menikah</option>
                                <option>Belum Menikah</option>
                                <option>Cerai Mati</option>
                                <option>Cerai Hidup</option>
                            </select>
                            </div>

                <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="pekerjaan">Status Pekerjaan</label>
                        </div>
                            <select class="custom-select" id="pekerjaan" name="pekerjaan">
                                <option selected>Pilih</option>
                                <option>Karyawan Swasta</option>
                                <option>Pegawai Negeri</option>
                                <option>Wiraswasta</option>
                                <option>BUMN</option>
                                <option>Mahasiswa</option>
                                <option>Tidak Bekerja</option>
                                <option>Lainnya</option>
                            </select>
                            </div>
                
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="penghasilan">Penghasilan</span>
                            </div>
                                <input type="number" name="penghasilan" class="form-control">
                                </div>

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="pendidikan">Pendidikan Terakhir</label>
                    </div>
                    <select class="custom-select" id="pendidikan" name="pendidikan">
                        <option selected>Pilih</option>
                        <option>Tidak Sekolah</option>
                        <option>SD</option>
                        <option>SMP</option>
                        <option>SMA</option>
                        <option>SMK</option>
                        <option>S1</option>
                        <option>S2</option>
                        <option>S3</option>
                    </select>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="dnbantuan">Jenis Bantuan</label>
                        </div>
                        <select class="custom-select" id="dnbantuan" name="dnbantuan">
                            <option selected>Pilih</option>
                            <option>BLT</option>
                            <option>VST</option>
                            <option>BANPROV</option>
                            <option>BANKAB</option>
                            <option>BANPERTANIAN</option>
                            <option>BANPERLUASAN</option>
                            <option>DTKS</option>
                            <option>NON DTKS</option>
                            <option>TIDAK ADA</option>
                        </select>
                    </div>

                    <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="agama">Agama</label>
                    </div>
                        <select class="custom-select" id="agama" name="agama">
                            <option selected>Pilih</option>
                            <option>ISLAM</option>
                            <option>KRISTEN</option>
                            <option>HINDU</option>
                            <option>BUDHA</option>
                        </select>
                        </div>

                            <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <label class="input-group-text" for="desa">Dusun</label>
                                  </div>
                            <select class="custom-select" id="desa" name="desa">
                                <option selected>Pilih</option>
                                <option>DUSUN PEDES 1</option>
                                <option>DUSUN PEDES 2</option>
                                <option>BAYUR 1</option>
                                <option>BAYUR 2</option>
                                <option>JATI MUKA</option>
                            </select>
                            </div>

                            <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <label class="input-group-text" for="jpenduduk">Jenis Penduduk</label>
                                  </div>
                                <select class="custom-select" id="jpenduduk" name="jpenduduk">
                                    <option>Pilih</option>
                                    <option>PENDATANG</option>
                                    <option>TETAP</option>
                                    <option>PINDAH</option>
                                </select>
                                </div>
                           
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Alamat</span>
                        </div>
                        <textarea class="form-control" name="alamat" id="alamat" aria-label="With textarea"></textarea>
                        </div>
                        </br>
                    <button type="submit" class="btn btn-primary float-right">Tambah Data</button>
            </form>
            </div>
            </div>
        </div>
    </div> 
</div>
</main>