<div id="layoutSidenav_content">
<main>
<div class="container">
<div class="row mt-3">
<div class="col-md-6">
<?php if ($this->session->flashdata('flash') ) : ?>
<div class="row mt-3">
<div class="col-md-6">
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    Data Berhasil<strong></strong>
    <?= $this->session->flashdata('flash'); ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
</div>
</div>
<?php endif; ?>
<div class="row mt-3">
    <div class="col-md-6">
    </div>
</div>
</div>
</main>
<div class="container-fluid">
<div class="card mb-4">
<div class="card-header">
    <i class="fas fa-table mr-1"></i>
    Daftar Penduduk
</div>
<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead> 
                <tr>
                <th><center>No</center></th>
                <th><center>Nik</center></th>
                <th><center>Nama</center></th>
                <th><center>Kelamin</center></th>
                <th><center>Alamat</center></th>
                <th><center>Status</center></th>
                <th><center>Dusun</center></th>
                <th><center>Aksi</center></th>
                </tr>
                <?php 
                $no = 1;
                foreach($penduduk as $u){ 
                ?>
            </thead>
            <tbody>
                <tr>
                <td><?php echo $no++ ?></td>
                            <td><?php echo $u->nik ?></td>
                            <td><?php echo $u->nama ?></td>
                            <td><?php echo $u->kelamin ?></td>
                            <td><?php echo $u->alamat ?></td>
                            <td><?php echo $u->jpenduduk ?></td>
                            <td><?php echo $u->desa ?></td>
                    <td onclick="javascript: return confirm('Anda yakin akan menghapus?')"><center><?php echo anchor('admin/hapus/'.$u->id, '<div class="btn btn-danger btn-sm" style="width: 10px; width: 70px;"><i class="fa fa-trash"></i>Hapus</div>')?></td>
                    <td><center><div class="btn btn-primary btn-sm" style="width: 10px; width:70px;"><i class="fa fa-edit"></i>Ubah</div></td>
                    <td><center><?php echo anchor('admin/cetakTetap/' . $u->id, '<div class="btn btn-success btn-sm" style="width: 10px; width: 70px;"><i class="fa fa-edit"></i>Cetak</div>') ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
        <form action="penduduk" method="post">
<div class="input-group mb-3">
    <div class="input-group-prepend">
        <span class="input-group-text" id="nik">NIK</span>
            </div>
                    <input type="number" name="nik" class="form-control">
                    </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="nokk">No. KK</span>
                </div>
                    <input type="number" name="nokk" class="form-control">
                    </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="nama">Nama Kepala Keluarga</span>
                    </div>
                    <input type="text" name="nama" class="form-control">
                        </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="tempat">Tempat Lahir</span>
                    </div>
                        <input type="text" name="tempat" class="form-control">
                        </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="tglahir">Tanggal Lahir</span>
                </div>
                        <input type="date" name="tglahir" class="form-control">
                            </div>

    <div class="input-group mb-3">
    <div class="input-group-prepend">
        <label class="input-group-text" for="kelamin">Jenis Kelamin</label>
            </div>
                <select class="custom-select" id="kelamin" name="kelamin">
                <option selected>Pilih</option>
                <option>Laki-Laki</option>
                <option>Perempuan</option>
                </select>
                </div>
    <h5>Daerah Tujuan</h5>
    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="desa">Dusun</label>
                </div>
                    <select class="custom-select" id="desa" name="desa">
                        <option selected>Pilih</option>
                        <option>DUSUN PEDES 1</option>
                        <option>DUSUN PEDES 2</option>
                        <option>BAYUR 1</option>
                        <option>BAYUR 2</option>
                        <option>JATI MUKA</option>
                    </select>
                    </div>
        
    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="rt">RT</label>
                </div>
                    <select class="custom-select" id="rt" name="rt">
                        <option selected>Pilih</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </select>
                    </div>       
                    
<div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="rw">RW</label>
                </div>
                    <select class="custom-select" id="rw" name="rw">
                        <option selected>Pilih</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </select>
                    </div>    
        
            <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="tgpindah">Tanggal Pindah</span>
                </div>
                        <input type="date" name="tgpindah" class="form-control">
                            </div>

        <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="alspindah">Alasan Pindah</label>
                </div>
                    <select class="custom-select" id="alspindah" name="alspindah">
                        <option selected>Pilih</option>
                        <option>Pekerjaan</option>
                        <option>Pendidikan</option>
                        <option>Keamanan</option>
                        <option>Kesehatan</option>
                        <option>Keluarga</option>
                    </select>
                    </div>
                    <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text">Alamat</span>
            </div>
            <textarea class="form-control" name="alamat" id="alamat" aria-label="With textarea"></textarea>
            </div>
            </br>
        <button type="submit" class="btn btn-primary float-right">Tambah Data</button>
        </form>
        </div>
        </div>
    </div>
    </div>
    <!--end Modal--->


    <!-- Modal -->
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Perbarui Data <Datag></Datag></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
    <?php if( validation_errors() ) : ?>
<div class="alert alert-danger" role="alert">
<?= validation_errors();?>
    </div>
<?php endif; ?>
    <?php foreach($penduduk as $u){?>
    <form action="<?php echo base_url().'admin/update';?>" method="post">
<div class="input-group mb-3">
    <div class="input-group-prepend">
        <span class="input-group-text" id="nik">NIK</span>
            </div>
                             <input type="hidden" name="id" value="<?php echo $u->id ?>">
                             <input type="number" name="nik" value="<?php echo $u->nik ?>" class="form-control" readonly>
                                </div>

              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="nama">Nama</span>
                             </div>
                                <input type="text" name="nama" value="<?php echo $u->nama ?>" class="form-control" readonly>
                                    </div>

              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="tglahir">Tanggal Lahir</span>
                            </div>
                                 <input type="date" name="tglahir" value="<?php echo $u->tglahir ?>" class="form-control">
                                     </div>

             <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="kelamin">Jenis Kelamin</label>
                     </div>
                         <select class="custom-select" id="kelamin" value="<?php echo $u->kelamin ?>" name="kelamin">
                            
                            <option>Laki-Laki</option>
                            <option>Perempuan</option>
                            </select>
                            </div>              

                            <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <label class="input-group-text" for="jpenduduk">Jenis Penduduk</label>
                                  </div>
                                <select class="custom-select" id="jpenduduk" value="<?php echo $u->jpenduduk ?>" name="jpenduduk">
                                    <option>PENDATANG</option>
                                    <option>TETAP</option>
                                </select>
                                </div>
                        </br>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
            <?php  } ?>
                </div>
                </div>
            </div>
            </div>
            </div>
        </div>
    </div>
</main>