<div id="layoutSidenav_content">
    <main>
    <div class="container">
    <div class="row mt-3">
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <label>
            <a href="<?php base_url('user/tampilbantuan')?>">
           <button type="button" class="btn btn-danger"><i class="fas fa-eye"></i> Lihat Data</button>
            </a>
            </label>
        </div>
        </div>
        <div class="navbar-form navbar-right">
        <?php echo form_open('user/search') ?>
        <input type="text" name="keyword" placeholder="Masukan Nama/Nik">
        <button type="submit" class="btn btn-primary">Cari</button>
        <?php echo form_close()?>
        </div>
       </label>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No.</th>
      <th scope="col">No.KK</th>
      <th scope="col">Nik</th>
      <th scope="col">Nama</th>
      <th scope="col">Kelamin</th>
      <th scope="col">Usia</th>
      <th scope="col">Pendidikan</th>
      <th scope="col">Pekerjaan</th>
      <th scope="col">Alamat</th>
      <th scope="col">Bantuan</th>
    </tr>
  </thead>
  <?php 
    $no = 1;
    foreach($penduduk as $u){ 
    ?>
  <tbody>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $u->nokk ?></td>
      <td><?php echo $u->nik ?></td>
      <td><?php echo $u->nama ?></td>
      <td><?php echo $u->kelamin ?></td>
      <td><?php echo $u->usia ?></td>
      <td><?php echo $u->pendidikan ?></td>
      <td><?php echo $u->pekerjaan ?></td>
      <td><?php echo $u->alamat ?></td>
      <td><?php echo $u->dnbantuan ?></td>
    </tr>
  </tbody>
  <?php } ?>
</table>
    </div>
    </main>
   