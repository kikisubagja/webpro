<div id="layoutSidenav_content">
    <main>
    <div class="container">
    <div class="row mt-3">
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <a href="<?php base_url('user/tampildatamutasi')?>">
            <div class="btn btn-danger"><i class="fas fa-eye"></i> Lihat Data</div>
            </a>
        </div>
        </div>
        <label>
        <div class="navbar-form navbar-right">
        <?php echo form_open('user/search2') ?>
        <input type="text" name="keyword" placeholder="Masukan Nama/Nik">
        <button type="submit" class="btn btn-primary">Cari</button>
        <?php echo form_close()?>
        </div>
       </label>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No.</th>
      <th scope="col">Nik</th>
      <th scope="col">Nama Mutasi</th>
      <th scope="col">Kelamin</th>
      <th scope="col">Usia</th>
      <th scope="col">Pendidikan</th>
      <th scope="col">Pekerjaan</th>
      <th scope="col">Alamat</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <?php 
    $no = 1;
    foreach($datamutasi as $u){ 
    ?>
  <tbody>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $u->nik_mutasi ?></td>
      <td><?php echo $u->nama_mutasi ?></td>
      <td><?php echo $u->kelamin_mutasi ?></td>
      <td><?php echo $u->usia_mutasi ?></td>
      <td><?php echo $u->pendidikan_mutasi ?></td>
      <td><?php echo $u->pekerjaan_mutasi ?></td>
      <td><?php echo $u->alamat_mutasi ?></td>
      <td><?php echo $u->jpenduduk_mutasi ?></td>
      </tr>
  </tbody>
  <?php } ?>
</table>
    </div>
    </main>
   