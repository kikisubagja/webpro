<div id="layoutSidenav_content">
<main>
<style>
.hilangdalamgelap {
  opacity: 0.5;
}
</style>
   <div class="container">
   <div class="row mt-3">
   </div>
   <div class="card text-center">
  <div class="card-header bg-dark">
    <div class="text-white">SIAK WEB PANEL</div>
  </div>
  <div class="card-body">
      <p class="card-text">Program Hasil Magang Mahasiswa STMIK Kharisma Karawang</p>
    <center>
    <div class="card" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Nama : Mochamad Kiki Subagja <br>NPM : 43E57006175037</li>
    <li class="list-group-item">Nama : Nezar Yuzdi Alamsyah <br>NPM : 43E57006175044</li>
    <li class="list-group-item">Prodi: Informatika</li>
  </ul>
  <hr>
  <div class="card-body">
    <li class="list-group-item">Pembimbing Akademik : Yessy Yanitasari,S.T,M.Kom</li>
    <li class="list-group-item">Pembimbing Teknik : <br>Naufal Iskandar</li>
  </div>
</div>
    </center>

  </div>
  <div class="card-footer text-muted bg-dark">
    <div class="text-white">Administrasi Kependudukan - © 2020 Desa Payungsari
  </div></div>
</div>