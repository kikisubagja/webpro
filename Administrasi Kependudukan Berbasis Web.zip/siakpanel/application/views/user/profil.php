s
        <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h3 class="mt-4">Selamat Datang </h3>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">My Profile</li>
                        </ol>
                        <div class="card-deck">
                        <div class="card">
                            
                            <img class="card-img-top" src="<?= base_url('assets/img/user.png'); ?>" style="width: 150px; height: auto;">
                            <?php foreach($tbl_kades as $u){ ?>
                            <div class="card-body">
                            <h5 class="card-title"></h5>
                            <p class="card-text"><span class="badge badge-pill badge-warning">Nama Lengkap</span>:<span class="badge badge-primary"><?php echo $u->nama?></span></p>
                            <p class="card-text"><span class="badge badge-pill badge-warning">Status Jabatan</span>:<span class="badge badge-primary"><?php echo $u->status?></span></p>
                            <p class="card-text"><span class="badge badge-pill badge-warning">Jabatan</span>:<span class="badge badge-success"><?php echo $u->jabatan?></span></p>
                            <p class="card-text"><small class="text-muted">Kantor Desa Payungsari</small></p>
                            </div>
                            <?php } ?>
                        </>
                    </div>
                </main>
