<div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark shadow navbar-light bg-primary" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading"><span class="badge badge-secondary">Halaman</span></div>
                            <a class="nav-link" href="<?= base_url('admin');?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                                <div class="text-black">Beranda</div>
                            </a>
                            <div class="sb-sidenav-menu-heading"><span class="badge badge-secondary">Konfigurasi Data</span></div>
                            <a class="nav-link" href="<?= base_url('admin/tampilpenduduk');?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                <div class="text-white">Data Penduduk</div>
                            </a>
                            <a class="nav-link" href="<?= base_url('admin/tampilbantuan')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-gift"></i></div>
                                <div class="text-white">Dana Bantuan</div>
                            </a>
                            <a class="nav-link" href="<?= base_url('admin/mutasiDataTampil')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-share-square"></i></div>
                                <div class="text-white">Data Mutasi</div>
                            </a>
                            <div class="sb-sidenav-menu-heading"><span class="badge badge-secondary">Konfigurasi User</span></div>
                            <a class="nav-link" href="<?= base_url('admin/tampiluser')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-users-cog"></i></div>
                                <div class="text-white">Data User</div>
                            </a>
                            <a class="nav-link" href="<?= base_url('admin/tampilkades')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-users-cog"></i></div>
                                <div class="text-white">Kepala Desa</div>
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small"></div>
                        Administrasi Kependudukan
                    </div>
                </nav>
            </div>