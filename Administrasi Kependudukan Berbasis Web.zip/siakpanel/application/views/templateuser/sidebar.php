<div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Halaman</div>
                            <a class="nav-link" href="<?= base_url('user');?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                                Beranda
                            </a>
                            <div class="sb-sidenav-menu-heading">Konfigurasi Data</div>
                            <a class="nav-link" href="<?= base_url('user/tampilpenduduk');?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Data Penduduk
                            </a>
                            <a class="nav-link" href="<?= base_url('user/tampilbantuan')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-gift"></i></div>
                                Dana Bantuan
                            </a>
                            <a class="nav-link" href="<?= base_url('user/mutasiDataTampil')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-share-square"></i></div>
                                Data Mutasi
                            </a>
                            <div class="sb-sidenav-menu-heading"></div>
                            <a class="nav-link" href="<?= base_url('auth');?>">
                                <div class="sb-nav-link-icon">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small"></div>
                        Administrasi Kependudukan
                    </div>
                </nav>
            </div>