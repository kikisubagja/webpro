<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->model('Penduduk_model', 'penduduk_model');

        // if($this->session->userdata('status') != 'Admin'){
        //     $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        //             Silakan <strong> Login Dahulu. </strong>
        //             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        //               <span aria-hidden="true">&times;</span>
        //             </button>
        //           </div>');
        //     redirect('Auth');
        // }
    }

    public function index() //menampilkan halaman awal ketika login *,*
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Beranda';
        $data['total'] = $this->Penduduk_model->getAllPenduduk();
        $data['totaldatang'] = $this->Penduduk_model->getAllPendudukDatang();
        $data['totaltetap'] = $this->Penduduk_model->getAllPendudukTetap();
        $data['totalpindah'] = $this->Penduduk_model->getAllPendudukPindah();
        $data['totalmutasi'] = $this->Penduduk_model->getAllMutasi();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/beranda', $data);
        $this->load->view('template/footer');
    }

    public function login()
    {
        $data['judul'] = 'Beranda';
        //$this->load->view('template/headlogin', $data);
        $this->load->view('admin/login');
        // $this->load->view('template/footer');
    }
    public function tambahPenduduk() // proses untuk menambahkan data penduduk kedalam database
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Tambah Data Penduduk';

        $this->form_validation->set_rules('nik', 'NIK', 'required|numeric');
        $this->form_validation->set_rules('nokk', 'NO.KK', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar');
            $this->load->view('admin/tambahpenduduk');
            $this->load->view('template/footer');
        } else {
            $this->Penduduk_model->tambahData();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/tampilpenduduk');
        }
    }
    public function tambahUser() // proses untuk menambahkan data penduduk kedalam database
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Tambah Data User';

        $this->form_validation->set_rules('nama', 'NAMA', 'required');
        $this->form_validation->set_rules('username', 'USERNAME', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar');
            $this->load->view('admin/tambahuser');
            $this->load->view('template/footer');
        } else {
            $this->Penduduk_model->tambahDataUser();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/tampiluser');
        }
    }
    public function tambahKades() // proses untuk menambahkan data penduduk kedalam database
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Tambah Data Kades';

        $this->form_validation->set_rules('nama', 'NAMA', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar');
            $this->load->view('admin/tambahkades');
            $this->load->view('template/footer');
        } else {
            $this->Penduduk_model->tambahDataKades();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/tampilkades');
        }
    }

    public function tampilPenduduk() //menampilkan data penduduk
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penduduk';
        $daftar['penduduk'] = $this->Penduduk_model->getAllData()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampilpenduduk', $daftar);
        $this->load->view('template/footer');
    }
    public function tampilUser() //menampilkan data penduduk
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar User';
        $daftar['user'] = $this->Penduduk_model->getDataUser()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampiluser', $daftar);
        $this->load->view('template/footer');
    }
    public function tampilKades() //menampilkan data penduduk
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Kepala Desa';
        $daftar['kades'] = $this->Penduduk_model->getDataKades()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampilkades', $daftar);
        $this->load->view('template/footer');
    }
    public function tampilBantuan() //menampilkan penerima bantuan
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penerima Bantuan';
        $daftar['penduduk'] = $this->Penduduk_model->getAllData()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampilbantuan', $daftar);
        $this->load->view('template/footer');
    }
    public function tampilPendatang() //menampilkan total di yang datang diberanda
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penduduk Pendatang';
        $daftar['penduduk'] = $this->Penduduk_model->getDataDatang()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/pendudukdatang', $daftar);
        $this->load->view('template/footer');
    }
    public function tampilTetap() //menampilkan total di yang tetap diberanda
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penduduk Tetap';
        $daftar['penduduk'] = $this->Penduduk_model->getDataTetap()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/penduduktetap', $daftar);
        $this->load->view('template/footer');
    }
    public function tampilPindah() // menampilkan total di yang pindah diberanda
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penduduk Pindah';
        $daftar['penduduk'] = $this->Penduduk_model->getDataPindah()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/pendudukpindah', $daftar);
        $this->load->view('template/footer');
    }
    public function hapus($id) // proses penghapus data per id
    {
        $this->load->model('Penduduk_model');

        $where = array('id' => $id);
        $this->Penduduk_model->hapus_data($where, 'tbl_penduduk');
        $this->session->set_flashdata('flash', 'Di Hapus');
        redirect('admin/tampilpenduduk');
    }
    public function hapusmutasi($id) // proses penghapus data per id
    {
        $this->load->model('Penduduk_model');

        $where = array('id_mutasi' => $id);
        $this->Penduduk_model->hapus_data($where, 'tbl_mutasi');
        $this->session->set_flashdata('flash', 'Di Hapus');
        redirect('admin/mutasidatatampil');
    }
    public function hapususer($id) // proses penghapus data per id
    {
        $this->load->model('Penduduk_model');

        $where = array('id_user' => $id);
        $this->Penduduk_model->hapus_data($where, 'user');
        $this->session->set_flashdata('flash', 'Di Hapus');
        redirect('admin/tampiluser');
    }
    public function hapuskades($id) // proses penghapus data per id
    {
        $this->load->model('Penduduk_model');

        $where = array('id_kpldesa' => $id);
        $this->Penduduk_model->hapus_data($where, 'tbl_kades');
        $this->session->set_flashdata('flash', 'Di Hapus');
        redirect('admin/tampilkades');
    }
    public function edit($id) // proses edit data per id
    {
        $this->load->model('Penduduk_model');

        $where = array('id' => $id);
        $data['judul'] = 'Form Ubah Data';
        $data['ubah_data'] = $this->Penduduk_model->edit_data($where, 'tbl_penduduk')->result();

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/ubah_data', $data);
        $this->load->view('template/footer');
    }
    public function update() // proses penyimpanan data yang diubah
    {
        /*
        if ($this->form_validation->run() == FALSE) {
            $data['judul'] = 'Ubah data';
            $data['u'] = $this->penduduk_model->edit_data(['id' => $id], 'tbl_penduduk');
            // var_dump($data['u']->row_array()); die;
            $data['u']->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar');
            $this->load->view('admin/ubah_data', $data);
            $this->load->view('template/footer');

        } else {
        */
        $this->load->model('Penduduk_model');

        $id = $this->input->post('id');
        $nama = $this->input->post('nama');
        $tempat = $this->input->post('tempat');
        $tglahir = $this->input->post('tglahir');
        $kelamin = $this->input->post('kelamin');
        $usia = $this->input->post('usia');
        $status = $this->input->post('status');
        $alamat = $this->input->post('alamat');
        $pekerjaan = $this->input->post('pekerjaan');
        $penghasilan = $this->input->post('penghasilan');
        $pendidikan = $this->input->post('pendidikan');
        $agama = $this->input->post('agama');
        $desa = $this->input->post('desa');
        $jpenduduk = $this->input->post('jpenduduk');
        $dnbantuan = $this->input->post('dnbantuan');
        $kecamatan = $this->input->post('kecamatan');
        $kabupaten = $this->input->post('kabupaten');
        $rt = $this->input->post('rt');
        $rw = $this->input->post('rw');
        $negara = $this->input->post('negara');

       
        $data = array(
            'nama' => $nama,
            'tempat' => $tempat,
            'tglahir' => $tglahir,
            'kelamin' => $kelamin,
            'usia' => $usia,
            'status' => $status,
            'alamat' => $alamat,
            'pekerjaan' => $pekerjaan,
            'penghasilan' => $penghasilan,
            'pendidikan' => $pendidikan,
            'agama' => $agama,
            'desa' => $desa,
            'jpenduduk' => $jpenduduk,
            'dnbantuan' => $dnbantuan,
            'kecamatan' => $kecamatan,
            'kabupaten' => $kabupaten,
            'rt' => $rw,
            'rw' => $rt,
            'negara' => $negara
        );

        $where = array(
            'id' => $id
        );

        $this->Penduduk_model->updateData($where, $data, 'tbl_penduduk');
        redirect('admin/tampilpenduduk');
    }
    //   public function print(){
    //       $this->load->model('Penduduk_model');

    //     $data['penduduk'] = $this->Penduduk_model->getAllData('tbl_penduduk')->result();
    //   $this->load->view('print_penduduk', $data);
    //   }
    public function cetak()
    {
        $this->load->model('Penduduk_model');
        //   $data['penduduk'] = $this->Penduduk_model->getAllData('tbl_penduduk')->result();
        $data['tbl_penduduk'] = $this->Penduduk_model->cetak_penduduk($this->uri->segment('3'));
        $this->load->view('admin/cetak_penduduk', $data);
    }
    public function cetakBantuan()
    {
        $this->load->model('Penduduk_model');
        //   $data['penduduk'] = $this->Penduduk_model->getAllData('tbl_penduduk')->result();
        $data['tbl_penduduk'] = $this->Penduduk_model->cetak_penduduk($this->uri->segment('3'));
        $this->load->view('admin/cetak_bantuan', $data);
    }
    public function cetakMutasi() // mencetak
    {
        $this->load->model('Penduduk_model');
        //   $data['penduduk'] = $this->Penduduk_model->getAllData('tbl_penduduk')->result();
        $data['tbl_mutasi'] = $this->Penduduk_model->cetak_mutasi($this->uri->segment('3'));
        $this->load->view('admin/cetak_mutasi', $data);
    }
    public function mutasiData() // Form untuk mutasi
    {
        $this->load->model('Penduduk_model');
        
        $data['judul'] = 'Form Data Mutasi';
        $id = $this->uri->segment(3);
        $data['mutasidata'] = $this->Penduduk_model->getDataMutasi2($id);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/mutasidata', $data);
        $this->load->view('template/footer');
    }
    public function mutasiDataTampil() // menampilkan data mutasi yang disimpan 
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Data Mutasi';
        $daftar['datamutasi'] = $this->Penduduk_model->getDataMutasi()->result();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampildatamutasi', $daftar);
        $this->load->view('template/footer');
    }
    public function mutasiDataSimpan() // proses penyimpanan data
    {    
            $this->load->model('Mutasi_model');
            $this->Mutasi_model->tambahDataMutasi();
           // var_dump();
            redirect('admin/tampilpenduduk');
        }
    public function search()
    {
        $this->load->model('Penduduk_model');
        $keyword = $this->input->post('keyword');
        $data['judul'] = 'Data Penduduk';
        $data['penduduk'] = $this->Penduduk_model->get_keyword($keyword);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampilpenduduk', $data);
        $this->load->view('template/footer');
    }
    public function search2()
    {
        $this->load->model('Penduduk_model');
        $keyword = $this->input->post('keyword');
        $data['judul'] = 'Data Mutasi';
        $data['datamutasi'] = $this->Penduduk_model->get_keyword2($keyword);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tampildatamutasi', $data);
        $this->load->view('template/footer');
    }
    public function editUser($id_user) // proses edit data per id
    {
        $this->load->model('Penduduk_model');

        $where = array('id_user' => $id_user);
        $data['judul'] = 'Form Ubah Data';
        $data['ubah_data'] = $this->Penduduk_model->edit_data($where, 'user')->result();

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/ubah_data_user', $data);
        $this->load->view('template/footer');
    }
    public function tentang() // proses edit data per id
    {
      
        $data['judul'] = 'Tentang Kami';

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/tentang');
        $this->load->view('template/footer');
    }
    public function bantuan() // proses edit data per id
    {
      
        $data['judul'] = 'Bantuan - Buku Panduan';

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar');
        $this->load->view('admin/bantuan');
        $this->load->view('template/footer');
    }
    public function updateUser() // proses penyimpanan data yang diubah
    {
        $this->load->model('Penduduk_model');

        $id_user = $this->input->post('id_user');
        $nama = $this->input->post('nama');
        $username = $this->input->post('username');
        $status = $this->input->post('status');
        $password = $this->input->post('password');

       
        $data = array(
            'nama' => $nama,
            'username' => $username,
            'status' => $status,
            'password' => $password
        );

        $where = array(
            'id_user' => $id_user
        );

        $this->Penduduk_model->updateData($where, $data, 'user');
        redirect('admin/tampiluser');
    }
}
