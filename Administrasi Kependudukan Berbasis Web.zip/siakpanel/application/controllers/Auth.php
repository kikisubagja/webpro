<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Auth extends CI_Controller {
  public function __construct(){
    parent::__construct();
    
    $this->load->model('Login_model', 'login');
    $this->session->sess_destroy();
     
  }

  public function index()
  {
    $this->load->library('form_validation');

    $this->form_validation->set_rules('username', 'Username', 'required', [
        'required' => 'Username harus diisi'
    ]);
    $this->form_validation->set_rules('password', 'Password', 'required', [
        'required' => 'Password harus diisi'
    ]);
    if ($this->form_validation->run() == FALSE) {
      $data['judul'] = 'Halaman Login';
      $this->load->view('template/headlogin', $data);
      $this->load->view('admin/login');
      $this->load->view('template/footerlogin');
    } else {
      $data = $this->login->login();
      // var_dump($data); die;
      $userdata = [
          'username' => $data['username'],
          'status' => $data['status']
      ];
      $this->session->set_userdata($userdata);

      if ($data['status'] == 'Admin') {
        //controller admin dipanggil
        redirect('Admin');      
      } else {
        redirect('User');
      }     
    }
  }

  public function logout(){
    $this->session->sess_destroy();
    
    redirect('Auth');
    

  }

}