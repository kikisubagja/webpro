<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->model('Penduduk_model', 'penduduk_model');
        if ($this->session->userdata('username')){
            redirect('auth');
        }

        // if($this->session->userdata('status') != 'Admin'){
        //     $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        //             Silakan <strong> Login Dahulu. </strong>
        //             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        //               <span aria-hidden="true">&times;</span>
        //             </button>
        //           </div>');
        //     redirect('Auth');
        // }
    }
    public function index()
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Beranda';
        $data['total'] = $this->Penduduk_model->getAllPenduduk();
        $data['totaldatang'] = $this->Penduduk_model->getAllPendudukDatang();
        $data['totaltetap'] = $this->Penduduk_model->getAllPendudukTetap();
        $data['totalpindah'] = $this->Penduduk_model->getAllPendudukPindah();
        $data['totalmutasi'] = $this->Penduduk_model->getAllMutasi();
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/beranda', $data);
        $this->load->view('templateuser/footer');
    }

    public function profile()
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Halaman Kepala Desa';
        $daftar['tbl_kades'] = $this->Penduduk_model->getDataKades()->result();
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/profil', $daftar);
        $this->load->view('templateuser/footer');
    }

    public function login()
    {
        $data['judul'] = 'Beranda';
        //$this->load->view('template/headlogin', $data);
        $this->load->view('admin/login');
        // $this->load->view('template/footer');
    }
   
    public function tampilPenduduk()
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penduduk';
        $daftar['penduduk'] = $this->Penduduk_model->getAllData()->result();
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/tampilpenduduk', $daftar);
        $this->load->view('templateuser/footer');
    }
    public function tampilBantuan()
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Daftar Penerima Bantuan';
        $daftar['penduduk'] = $this->Penduduk_model->getAllData()->result();
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/tampilbantuan', $daftar);
        $this->load->view('templateuser/footer');
    }
    //   public function print(){
    //       $this->load->model('Penduduk_model');

    //     $data['penduduk'] = $this->Penduduk_model->getAllData('tbl_penduduk')->result();
    //   $this->load->view('print_penduduk', $data);
    //   }
    public function mutasiDataTampil() // menampilkan data mutasi yang disimpan 
    {
        $this->load->model('Penduduk_model');
        $data['judul'] = 'Data Mutasi';
        $daftar['datamutasi'] = $this->Penduduk_model->getDataMutasi()->result();
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/tampildatamutasi', $daftar);
        $this->load->view('templateuser/footer');
    }
    public function search()
    {
        $this->load->model('Penduduk_model');
        $keyword = $this->input->post('keyword');
        $data['judul'] = 'Data Penduduk';
        $data['penduduk'] = $this->Penduduk_model->get_keyword($keyword);
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/tampilpenduduk', $data);
        $this->load->view('templateuser/footer');
    }
    public function search2()
    {
        $this->load->model('Penduduk_model');
        $keyword = $this->input->post('keyword');
        $data['judul'] = 'Data Penduduk Mutasi';
        $data['datamutasi'] = $this->Penduduk_model->get_keyword2($keyword);
        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/tampildatamutasi', $data);
        $this->load->view('templateuser/footer');
    }
    public function tentang() // proses edit data per id
    {
      
        $data['judul'] = 'Tentang Kami';

        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/tentang');
        $this->load->view('templateuser/footer');
    }
    public function bantuan() // proses edit data per id
    {
      
        $data['judul'] = 'Bantuan - Buku Panduan';

        $this->load->view('templateuser/header', $data);
        $this->load->view('templateuser/sidebar');
        $this->load->view('user/bantuan');
        $this->load->view('templateuser/footer');
    }

}
