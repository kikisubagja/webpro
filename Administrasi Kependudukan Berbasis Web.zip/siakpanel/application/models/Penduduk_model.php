<?php

class Penduduk_model extends CI_model
{
    public function getAllData()
    {
        return $this->db->get('tbl_penduduk');
    }
    public function getDataMutasi2($id)
    {
      $query = $this->db->query("SELECT * FROM tbl_penduduk WHERE id='$id'");
      return $query->result();   
    }
    public function getDataKades()
    {
        return $this->db->get('tbl_kades');
    }
    public function getDataUser()
    {
        return $this->db->get('user');
    }
    public function getAllPenduduk()
    {
        $query = $this->db->get('tbl_penduduk');
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        } else {
            return 0;
        }
    }
    public function getAllMutasi()
    {
        $query = $this->db->get('tbl_mutasi');
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        } else {
            return 0;
        }
    }
    //////////////////////////////////////////////////////////////////////////////////
    public function getAllPendudukDatang() //beranda
    {
        $this->db->where('jpenduduk', 'PENDATANG');
        return $this->db->count_all_results('tbl_penduduk');
    }
    public function getAllPendudukTetap() //beranda
    {
        $this->db->where('jpenduduk', 'TETAP');
        return $this->db->count_all_results('tbl_penduduk');
    }
    public function getAllPendudukPindah() //beranda
    {
        $this->db->where('jpenduduk', 'PINDAH');
        return $this->db->count_all_results('tbl_penduduk');
    }
    ///////////////////////////////////////////////////////////////////////////////////
    public function getDataMutasi() // menampilkan table pendatang
    {
        return $this->db->get('tbl_mutasi');
    }
 /*   public function getDataDatang() // menampilkan table pendatang
    {
        return $this->db->get_where('tbl_penduduk', array('jpenduduk' => 'PENDATANG'));
    }
    public function getDataTetap() // menampilkan table tetap
    {
        return $this->db->get_where('tbl_penduduk', array('jpenduduk' => 'TETAP'));
    }
    public function getDataPindah() // menampilkan table tetap
    {
        return $this->db->get_where('tbl_penduduk', array('jpenduduk' => 'PINDAH'));
    }
   /* public function getDataBantuan() // menampilkan table pindah
   /{
        return $this->db->get_where('tbl_penduduk', array('dnbantuan' => 'BLT','VST','BANPROV','BANKAB','BANPERTANIAN','BANPERLUASAN','DTKS','NON DTKS'));
    }*/
    ///////////////////////////// menambahkan data 
    public function tambahData()
    {
        $data = [
            "nik" => $this->input->post('nik', true),
            "nokk" => $this->input->post('nokk', true),
            "nama" => $this->input->post('nama', true),
            "tglahir" => $this->input->post('tglahir'),
            "tempat" => $this->input->post('tempat', true),
            "kelamin" => $this->input->post('kelamin'),
            "usia" => $this->input->post('usia'),
            "status" => $this->input->post('status'),
            "alamat" => $this->input->post('alamat', true),
            "pekerjaan" => $this->input->post('pekerjaan'),
            "penghasilan" => $this->input->post('penghasilan', true),
            "pendidikan" => $this->input->post('pendidikan'),
            "agama" => $this->input->post('agama'),
            "desa" => $this->input->post('desa'),
            "jpenduduk" => $this->input->post('jpenduduk'),
            "dnbantuan" => $this->input->post('dnbantuan'),
            "kecamatan" => $this->input->post('kecamatan', true),
            "kabupaten" => $this->input->post('kabupaten', true),
            "rt" => $this->input->post('rt', true),
            "rw" => $this->input->post('rw', true),
            "negara" => $this->input->post('negara', true)
           //"id_user" => $this->input->post('id_user', true)
        ];

        $this->db->insert('tbl_penduduk', $data);
    }
    
    public function tambahDataUser()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "username" => $this->input->post('username', true),
            "password" => $this->input->post('password', true),
            "status" => $this->input->post('status', true)
        ];

        $this->db->insert('user', $data);
    }
    public function tambahDataKades()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "status" => $this->input->post('status', true),
            "jabatan" => $this->input->post('jabatan', true)
        ];

        $this->db->insert('tbl_kades', $data);
    }
    public function hapus_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    public function edit_data($where, $table)
    {
        return $this->db->get_where($table, $where);
    }
    public function updateData($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    public function cetak_penduduk($id)
    {
        $this->db->from('tbl_penduduk');
        $this->db->where('id', $id);
        return $this->db->get()->result_array();
    }
    public function cetak_mutasi($id)
    {
        $this->db->from('tbl_mutasi');
        $this->db->where('id_mutasi', $id);
        return $this->db->get()->result_array();
    }
    public function get_keyword($keyword)
    {
        $this->db->select('*');
        $this->db->from('tbl_penduduk');
        $this->db->like('nik',$keyword);
        $this->db->or_like('nokk', $keyword);
        $this->db->or_like('nama', $keyword);
        return $this->db->get()->result();
    }
    public function get_keyword2($keyword)
    {
        $this->db->select('*');
        $this->db->from('tbl_mutasi');
        $this->db->like('nik_mutasi',$keyword);
        $this->db->or_like('nokk_mutasi', $keyword);
        $this->db->or_like('nama_mutasi', $keyword);
        return $this->db->get()->result();
    }
}
