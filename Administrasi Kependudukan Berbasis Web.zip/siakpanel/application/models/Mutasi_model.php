<?php

class Mutasi_model  extends CI_model{

    public function tambahDataMutasi()
    {
        $data = [
            "nik_mutasi" => $this->input->post('nik_mutasi', true),
            "nokk_mutasi" => $this->input->post('nokk_mutasi', true),
            "nama_mutasi" => $this->input->post('nama_mutasi', true),
            "tglahir_mutasi" => $this->input->post('tglahir_mutasi'),
            "tempat_mutasi" => $this->input->post('tempat_mutasi', true),
            "kelamin_mutasi" => $this->input->post('kelamin_mutasi'),
            "usia_mutasi" => $this->input->post('usia_mutasi'),
            "status_mutasi" => $this->input->post('status_mutasi'),
            "alamat_mutasi" => $this->input->post('alamat_mutasi', true),
            "pekerjaan_mutasi" => $this->input->post('pekerjaan_mutasi'),
            "penghasilan_mutasi" => $this->input->post('penghasilan_mutasi', true),
            "pendidikan_mutasi" => $this->input->post('pendidikan_mutasi'),
            "agama_mutasi" => $this->input->post('agama_mutasi'),
            "desa_mutasi" => $this->input->post('desa_mutasi'),
            "jpenduduk_mutasi" => $this->input->post('jpenduduk_mutasi'),
            "dnbantuan_mutasi" => $this->input->post('dnbantuan_mutasi'),
            "kecamatan_mutasi" => $this->input->post('kecamatan_mutasi', true),
            "kabupaten_mutasi" => $this->input->post('kabupaten_mutasi', true),
            "rt_mutasi" => $this->input->post('rt_mutasi', true),
            "rw_mutasi" => $this->input->post('rw_mutasi', true),
            "negara_mutasi" => $this->input->post('negara_mutasi', true)
            //"id_user" => $this->input->post('id_user', true)
        ];

        $this->db->insert('tbl_mutasi', $data);
        //$insert_id = $this->db->insert_id();
        if ($hasil == true) {
            # jika sudah berhasil mutasi maka hapus
            $query_delete = "DELETE FROM tbl_penduduk WHERE id = $id";
          
            $hasil_delete = mysqli_query($db, $query_delete);
          }
          
    }
}