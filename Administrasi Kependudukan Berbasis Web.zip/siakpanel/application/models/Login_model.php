<?php

    class Login_model extends CI_model{
        
        public function login()
        {
            $username = $this->input->post('username', true);
            $password = $this->input->post('password');
         
            $user = $this->db->get_where('user', ['username' => $username])->row_array();

            if ($user) {
                if ($user['password'] === $password) {
                    return $user;
                } else {
                    //jika password tidak sama
                    $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Password <strong> Tidak Sesuai </strong> Silakan Masukan Kembali.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>');
                  redirect('Auth');
                }
            } else {
                //jika user belum terdaftar
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    User <strong> Tidak Ditemukan. </strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>');
                  redirect('Auth');
            }
            
        }

    }