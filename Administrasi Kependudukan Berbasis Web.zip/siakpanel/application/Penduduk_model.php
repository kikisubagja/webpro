<?php

class Penduduk_model extends CI_model
{
    public function getAllData()
    {
        return $this->db->get('tbl_penduduk');
    }
    public function getAllPenduduk()
    {
        $query = $this->db->get('tbl_penduduk');
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        } else {
            return 0;
        }
    }
    public function getAllPendudukDatang() //beranda
    {
        $this->db->where('jpenduduk', 'PENDATANG');
        return $this->db->count_all_results('tbl_penduduk');
    }
    public function getAllPendudukTetap() //beranda
    {
        $this->db->where('jpenduduk', 'TETAP');
        return $this->db->count_all_results('tbl_penduduk');
    }
    public function getAllPendudukPindah() //beranda
    {
        $this->db->where('jpenduduk', 'PINDAH');
        return $this->db->count_all_results('tbl_penduduk');
    }
    public function getDataDatang() // menampilkan table pendatang
    {
        return $this->db->get_where('tbl_penduduk', array('jpenduduk' => 'PENDATANG'));
    }
    public function getDataTetap() // menampilkan table tetap
    {
        return $this->db->get_where('tbl_penduduk', array('jpenduduk' => 'TETAP'));
    }
    public function getDataPindah() // menampilkan table tetap
    {
        return $this->db->get_where('tbl_penduduk', array('jpenduduk' => 'PINDAH'));
    }
    public function tambahData()
    {
        $data = [
            "nik" => $this->input->post('nik', true),
            "nokk" => $this->input->post('nokk', true),
            "nama" => $this->input->post('nama', true),
            "tglahir" => $this->input->post('tglahir'),
            "tempat" => $this->input->post('tempat', true),
            "kelamin" => $this->input->post('kelamin'),
            "usia" => $this->input->post('usia'),
            "status" => $this->input->post('status'),
            "alamat" => $this->input->post('alamat', true),
            "pekerjaan" => $this->input->post('pekerjaan'),
            "penghasilan" => $this->input->post('penghasilan', true),
            "pendidikan" => $this->input->post('pendidikan'),
            "agama" => $this->input->post('agama'),
            "desa" => $this->input->post('desa'),
            "jpenduduk" => $this->input->post('jpenduduk'),
            "dnbantuan" => $this->input->post('dnbantuan'),
            "kecamatan" => $this->input->post('kecamatan', true),
            "kabupaten" => $this->input->post('kabupaten', true),
            "rt" => $this->input->post('rt', true),
            "rw" => $this->input->post('rw', true),
            "tgpindah" => $this->input->post('tgpindah', true),
            "alspindah" => $this->input->post('alspindah', true)
        ];

        $this->db->insert('tbl_penduduk', $data);
    }

    public function hapus_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    public function edit_data($where, $table)
    {
        return $this->db->get_where($table, $where);
    }
    public function updateData($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    public function cetak_penduduk($id)
    {
        $this->db->from('tbl_penduduk');
        $this->db->where('id', $id);
        //	$this->db->join('tka', 'tka.id_tka=surat_keterangan_tka.id_tka');
        //	$this->db->join('perusahaan', 'surat_keterangan_tka.id_perusahaan = perusahaan.id_perusahaan');
        return $this->db->get()->result_array();
    }
}
